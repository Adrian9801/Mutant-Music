# Mutant-Music
App que realiza operaciones y transformaciones a música previamente grabada en formato Wav, a 44.1Khz y 16 bit Depth en 2 canales
